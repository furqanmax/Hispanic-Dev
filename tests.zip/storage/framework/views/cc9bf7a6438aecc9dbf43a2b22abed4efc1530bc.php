
<?php $__env->startSection('content'); ?>
    <section style="background-image: url('svg/ads.png');height:100px;">

    </section>
    <section class="my-3">
        <div class="container-fluid">
            <div class="row m-0 p-0">
                <div class="col-md-2">
                    <img src="<?php echo e(asset('svg/profile.jpg')); ?>" width="100" height="100" class="rounded-circle" alt="">
                    <h3 class="text-18 font-weight-bold pt-3">
                        Tauseef Ahmed
                    </h3>
                    <h4 class="text-16">
                        tauseefahmed782@gmail.com
                    </h4>

                    <ul class="list-group mt-2">
                        <a href="<?php echo e(route('add.new.post')); ?>" class="text-color">
                            <li class="list-group-item  ">Add New Post</li>
                        </a>
                        <li class="list-group-item ">My Posts</li>
                        <li class="list-group-item">Draft</li>
                        <li class="list-group-item">Change profile</li>
                        <li class="list-group-item active">My Ads</li>
                        <li class="list-group-item">My Yellow</li>
                        <li class="list-group-item">Subscription</li>
                        <li class="list-group-item ">Event Creation</li>
                        <li class="list-group-item">Activities</li>
                        <li class="list-group-item">Notifications</li>
                    </ul>
                </div>
                <div class="col-md-8">
                    
                    <h3 class="text-22 font-weight-bold">
                        Edit Profile
                     </h3>

                     
                     <hr>
                     <div class="row">
                         <div class="col-md-7">
                            <div class="edit-form">
                                <form action="" class="grey-color text-14">
                                   <div class="row">
                                       <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="font-weight-bold "> Name</label>
                                            <input type="text" name="" id="" class="form-control text-14 grey-color" placeholder=" Name" aria-describedby="">
                                        </div>
                                       </div>
                                       <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="font-weight-bold ">Email</label>
                                            <input type="email" name="" id="" class="form-control text-14 grey-color" placeholder="Email" aria-describedby="">
                                        </div>
                                       </div>
                                       <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="font-weight-bold ">Phone Number</label>
                                            <input type="number" name="" id="" class="form-control text-14 grey-color" placeholder="+91 685 785 7885" aria-describedby="">
                                        </div>
                                       </div>
                                       <div class="col-md-6">
                                           <div class="form-group">
                                             <label for="" class="font-weight-bold">Gender</label>
                                             <select class="form-control  text-14 grey-color" name="" id="">
                                               <option>Change Gender</option>
                                               <option>Male</option>
                                               <option>Female</option>
                                             </select>
                                           </div>
                                       </div>
                                       <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="font-weight-bold "> Langauge</label>
                                            <input type="text" name="" id="" class="form-control text-14 grey-color" placeholder=" English" aria-describedby="">
                                        </div>
                                       </div>
                                       <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="" class="font-weight-bold "> Location</label>
                                            <input type="text" name="" id="" class="form-control text-14 grey-color" placeholder=" Hyderabad, India" aria-describedby="">
                                        </div>
                                       </div>
                                   </div>
                                   
                                   <div class="row">
                                       <div class="col-md-6">
                                        <a href="" class="btn btn-border font-weight-bold text-color btn-md btn-block shadow-none waves-effect waves-light">Back To Home</a>

                                       </div>
                                       <div class="col-md-6">
                                        <a href="" class="btn btn-custom font-weight-bold  btn-md btn-block shadow-none waves-effect waves-light">Save</a>
                                       </div>
                                   </div>
                                </form>
                            </div>
                         </div>
                     </div>
                    
                </div>
                <div class="col-md-2 text-center">
                    <img src="<?php echo e(asset('svg/ads2.jpg')); ?>" class="img img-fluid" style="height: 700px;" alt="">
                </div>
            </div>
        </div>
    </section>

    <!-- Button trigger modal -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\hispanic\resources\views/edit_profile.blade.php ENDPATH**/ ?>