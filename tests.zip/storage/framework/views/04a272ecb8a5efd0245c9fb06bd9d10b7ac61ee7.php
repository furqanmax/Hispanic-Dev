
<?php $__env->startSection('content'); ?>
    <section style="background-image: url('svg/ads.png');height:100px;">

    </section>
    <section class="my-3">
        <div class="container-fluid">
            <div class="row m-0 p-0">
                <div class="col-md-2">
                    <img src="<?php echo e(asset('svg/profile.jpg')); ?>" width="100" height="100" class="rounded-circle" alt="">
                    <h3 class="text-18 font-weight-bold pt-3">
                        Tauseef Ahmed
                    </h3>
                    <h4 class="text-16">
                        tauseefahmed782@gmail.com
                    </h4>

                    <ul class="list-group mt-2">
                        <a href="<?php echo e(route('add.new.post')); ?>" class="text-color">
                            <li class="list-group-item  ">Add New Post</li>
                        </a>
                        <li class="list-group-item ">My Posts</li>
                        <li class="list-group-item">Draft</li>
                        <li class="list-group-item">Change profile</li>
                        <li class="list-group-item">My Ads</li>
                        <li class="list-group-item">My Yellow</li>
                        <li class="list-group-item">Subscription</li>
                        <li class="list-group-item active">Event Creation</li>
                        <li class="list-group-item">Activities</li>
                        <li class="list-group-item">Notifications</li>
                    </ul>
                </div>
                <div class="col-md-8">
                    
                    <h3 class="text-22 font-weight-bold mb-0 pb-2">
                        Job Posting
                    </h3>
                    
                    
                   <form action="" class="grey-color text-14 mt-4">
                       
                       <div class="wrapper ">
                        <input type="file" id="file-input" >
                        <label for="file-input">
                            <i class="fa fa-plus"></i>
                            <span>Add </span>
                        </label>
                        <i class="fa fa-times-circle remove"></i>
                    </div>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold">Please choose a category</label>
                                    <select class="form-control custom-select text-14 grey-color" name="" id="">
                                      <option>Choose category</option>
                                      <option></option>
                                      <option></option>
                                    </select>
                                  </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold ">Posting Title</label>
                                    <input type="text" name="" id="" class="form-control text-14 grey-color" placeholder="Name" >
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold">Employment type
                                    </label>
                                    <select class="form-control custom-select text-14 grey-color" name="" id="">
                                      <option>Employment type
                                    </option>
                                      <option></option>
                                      <option></option>
                                    </select>
                                  </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold">Job type

                                    </label>
                                    <select class="form-control custom-select text-14 grey-color" name="" id="">
                                      <option>Job type

                                    </option>
                                      <option></option>
                                      <option></option>
                                    </select>
                                  </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold ">Compensation</label>
                                    <input type="text" name="" id="" class="form-control text-14 grey-color" placeholder="Describe Compensation" >
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold">Company name

                                    </label>
                                    <select class="form-control custom-select text-14 grey-color" name="" id="">
                                      <option>Company name

                                    </option>
                                      <option></option>
                                      <option></option>
                                    </select>
                                  </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold ">Zip code</label>
                                    <input type="text" name="" id="" class="form-control text-14 grey-color" placeholder="65898 698578" >
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold ">City</label>
                                    <input type="text" name="" id="" class="form-control text-14 grey-color" placeholder="Enter City" >
                                </div>
                            </div>
                        
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold">State

                                    </label>
                                    <select class="form-control custom-select text-14 grey-color" name="" id="">
                                      <option>Maharashtra

                                    </option>
                                      <option></option>
                                      <option></option>
                                    </select>
                                  </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold ">Email</label>
                                    <input type="email" name="" id="" class="form-control text-14 grey-color" placeholder="Email" >
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold">Email privacy options

                                    </label>
                                    <select class="form-control custom-select text-14 grey-color" name="" id="">
                                      <option>Select email

                                    </option>
                                      <option></option>
                                      <option></option>
                                    </select>
                                  </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold ">Phone number</label>
                                    <input type="number" name="" id="" class="form-control text-14 grey-color" placeholder="Enter phone number" >
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold">Phone number type

                                    </label>
                                    <select class="form-control custom-select text-14 grey-color" name="" id="">
                                      <option>Phone Type

                                    </option>
                                      <option></option>
                                      <option></option>
                                    </select>
                                  </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold ">Extenion</label>
                                    <input type="text" name="" id="" class="form-control text-14 grey-color" placeholder="extenion" >
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="" class="font-weight-bold ">Contact name</label>
                                    <input type="text" name="" id="" class="form-control text-14 grey-color" placeholder="contact name" >
                                </div>
                            </div>
    
                        </div>
                        
                        <div class="form-check">
                          <label class="form-check-label">
                            <input type="checkbox" class="form-check-input" name="" id="" value="checkedValue" checked>
                            ok to highlight this job opening for persons with disabilities
                          </label>
                        </div>
                        
                        <textarea  name="editor1" id="editor1" ></textarea>
                    </form>

                    
                    <div class="mt-3">
                        <div class="row ">
                            <div class="col-md-6">
                                <a href=""
                                    class="btn btn-border font-weight-bold  btn-md btn-block shadow-none waves-effect waves-light"
                                    data-toggle="modal" data-target="#eventmodal">Priview</a>
                            </div>
                            <div class="col-md-6">
                                <a href=""
                                    class="btn btn-custom font-weight-bold  btn-md btn-block shadow-none waves-effect waves-light">Post</a>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-2 text-center">
                    <img src="<?php echo e(asset('svg/ads2.jpg')); ?>" class="img img-fluid" style="height: 700px;" alt="">
                </div>
            </div>
        </div>
    </section>

<!-- Priview  -->
<div class="modal fade" id="eventmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered -0 p-0" role="document">


    <div class="modal-content">

        <div class="modal-body">
           
           <div class="row">
               <div class="col-md-8">
                    
           <h3 class="text-22 font-weight-bold">
            Vacancy for Php Associate
           </h3>
           
           <p class="text-14 pb-2 mb-0">
               Google
           </p>
           <p class="text-left pb-2 mb-0">
            Softwere Engineer
        </p>
               </div>
               <div class="col-md-4 text-14">
                   <p class="pb-2 mb-0">
                      <img src="<?php echo e(asset('svg/phone.svg')); ?>" alt="" class="img img-fluid">&nbsp; <b class="font-weight-bold">+61 2578 8577</b>
                   </p>
                   <p class="pb-2 mb-0">
                    <img src="<?php echo e(asset('svg/map-pin.svg')); ?>" alt="" class="img img-fluid">&nbsp; 500081, Hyderabad, Hi tech city, white fields, Kondapur
                   </p>
               </div>
           </div>
           <hr>
           
           <p class="font-weight-bold mt-3">
            Featured Videos & images
           </p>
           
           <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item">
                <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(35).jpg">
              </div>
              <div class="carousel-item active">
                <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(33).jpg">
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(31).jpg">
              </div>
            </div>
          </div>
          
          <div>
              
              <table class="table  table-borderless text-14 mt-3" >
                  <tbody >
                      <tr>
                          <td scope="row" class="font-weight-bold m-0 p-0" >Employment type</td>
                          <td class="m-0 p-0">
                            Contract
                          </td>
                          <td></td>
                      </tr>
                      <tr class="">
                          <td  class="font-weight-bold m-0 p-0">Categories</td>
                          <td class="m-0 pb-0">Restaurants, Asian Restaurants, Bartending Service,</td>
                      </tr>
                      <tr>
                          <td class="font-weight-bold m-0 p-0">Email</td>
                          <td class="m-0 p-0">hispanic@gmail.com</td>
                      </tr>
                      
                  </tbody>
              </table>
              <p class="font-weight-bold">
                  Description
              </p>
              <p>
                When leading companies choose Google Cloud it's a huge win for spreading the power of cloud computing globally. Once educational institutions, government agencies, and other businesses sign on to use Google Cloud products, you come in to facilitate making their work more productive, mobile, and collaborative. You listen and deliver what is most helpful for the customer. You assist fellow sales Googlers by problem-solving key technical issues for our customers. You liaise with the product marketing management and engineering teams to stay on top of industry trends and devise enhancements to Google Cloud products.
                product marketing management and engineering teams to stay on top of industry trends and devis
               product marketing management and engineering teams to stay on top of industry trends and devise enhancements to Goog
              </p>
          </div>
        </div>
        <div class="modal-footer">
            <div class="text-center m-auto">
                <button type="button" class="btn btn-custom font-weight-bold shadow-none btn-sm">Edit</button>
                <button type="button" class="btn btn-border font-weight-bold shadow-none btn-sm">Pay And
                    Post</button>

            </div>
        </div>
    </div>
</div>
</div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\hispanic\resources\views/jobs/hiring.blade.php ENDPATH**/ ?>