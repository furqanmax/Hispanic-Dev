
<?php $__env->startSection('content'); ?>
    <section style="background-image: url('svg/ads.png');height:100px;">

    </section>
    <section class="my-3">
        <div class="container-fluid">
            <div class="row m-0 p-0">
                <div class="col-md-2">
                    <img src="<?php echo e(asset('svg/profile.jpg')); ?>" width="100" height="100" class="rounded-circle" alt="">
                    <h3 class="text-18 font-weight-bold pt-3">
                        Tauseef Ahmed
                    </h3>
                    <h4 class="text-16">
                        tauseefahmed782@gmail.com
                    </h4>

                    <ul class="list-group mt-2">
                        <a href="<?php echo e(route('add.new.post')); ?>" class="text-color">
                            <li class="list-group-item  ">Add New Post</li>
                        </a>
                        <li class="list-group-item active">My Posts</li>
                        <li class="list-group-item">Draft</li>
                        <li class="list-group-item">Change profile</li>
                        <li class="list-group-item">My Ads</li>
                        <li class="list-group-item">My Yellow</li>
                        <li class="list-group-item">Subscription</li>
                        <li class="list-group-item">Event Creation</li>
                        <li class="list-group-item">Activities</li>
                        <li class="list-group-item">Notifications</li>
                    </ul>
                </div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-6 d-flex align-items-center">
                            <h3 class="text-22 font-weight-bold">
                                My Posts
                            </h3>
                        </div>
                        <div class="col-md-6 text-right">
                            <ul class="list-inline mb-0 pb-0">
                                <li class="list-inline-item">
                                    <div class="input-group md-form form-sm form-2 pl-0">
                                        <input class="form-control my-0 py-1 input red-border" type="text" placeholder="Search"
                                            aria-label="Search">
                                        <div class="input-group-append">
                                            <span class="input-group-text btn-custom"   id="basic-text1" style="background:#addfc6;"><i
                                                    class="fas fa-search " aria-hidden="true"></i></span>
                                        </div>
                                    </div>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-filter" aria-hidden="true"></i>
                                </li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="tabs">
                        <ul class="nav nav-tabs m-0 p-0" id="myTab" role="tablist">
                            <li class="nav-item">
                              <a class="nav-link px-3 badge active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
                                aria-selected="true">most recent</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link px-3 badge" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile"
                                aria-selected="false">active</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link px-3 badge" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact"
                                aria-selected="false">inactive</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link px-3 badge" id="postings-tab" data-toggle="tab" href="#postings" role="tab" aria-controls="posting"
                                  aria-selected="false"> all postings</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link px-3 badge" id="wanted-tab" data-toggle="tab" href="#wanted" role="tab" aria-controls="wanted"
                                  aria-selected="false">Wanted</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link px-3 badge" id="sellbuy-tab" data-toggle="tab" href="#sellbuy" role="tab" aria-controls="sellbuy"
                                  aria-selected="false">Sell\Buy</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link px-3 badge" id="classified-tab" data-toggle="tab" href="#classified" role="tab" aria-controls="classified"
                                  aria-selected="false">classified</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link badge" id="events-tab" data-toggle="tab" href="#events" role="tab" aria-controls="events"
                                  aria-selected="false">Events</a>
                              </li>
                              
                          </ul>
                          <div class="tab-content" id="myTabContent">
                            <div class="tab-pane mt-3 fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <div class="posts">
                                    <p class="  text-16 py-2  m-0">
                                        <span class="">
                                            July 14
                                        </span>
                                        <span class=" text-16">
                                            It is a long established fact that a reader will be distracted by will be distracted by the readable conte...More
                                        </span>
                                        &ensp;
                                            <span class="badge  btn-custom shadow-none px-2 py-1">  Rs 1200</span>
                                            &ensp;
                                        <span class="color_secondary">
                                            Pic
                                        </span>
                                    </p>
                                    <p class="  text-16 py-2  m-0">
                                        <span class="">
                                            July 14
                                        </span>
                                        <span class=" text-16">
                                            It is a long established fact that a reader will be distracted by will be distracted by the readable conte...More
                                        </span>
                                        &ensp;
                                            <span class="badge  btn-custom shadow-none px-2 py-1">  Rs 1200</span>
                                            &ensp;
                                        <span class="color_secondary">
                                            Pic
                                        </span>
                                    </p>
                                    <p class="  text-16 py-2  m-0">
                                        <span class="">
                                            July 14
                                        </span>
                                        <span class=" text-16">
                                            It is a long established fact that a reader will be distracted by will be distracted by the readable conte...More
                                        </span>
                                        &ensp;
                                            <span class="badge  btn-custom shadow-none px-2 py-1">  Rs 1200</span>
                                            &ensp;
                                        <span class="color_secondary">
                                            Pic
                                        </span>
                                    </p>
                                  </div>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">

                            </div>
                            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">

                            </div>
                          </div>
                    </div>
                     



                   </div>
                <div class="col-md-2 text-center">
                    <img src="<?php echo e(asset('svg/ads2.jpg')); ?>" class="img img-fluid" alt="">
                </div>
            </div>
        </div>
    </section>

    <!-- Button trigger modal -->

  
  <!-- Modal -->
  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="true">
  
    <!-- Add .modal-dialog-centered to .modal-dialog to vertically center the modal -->
    <div class="modal-dialog modal-dialog-centered -0 p-0" role="document">
  
  
      <div class="modal-content">
        <div class="modal-header m-0 p-0">
        <img src="<?php echo e(asset('svg/Rectangle.png')); ?>" class="img img-fluid" alt="">
        </div>
        <div class="modal-body">
          <p class="text-14 m-0 pb-1">
            06-23-2021
          </p>
          <h3 class="text-18">
            Post Title
          </h3>
          <ul class="list-inline list-post text-16">
              <li class="list-inline-item">
                Post type  
              </li>
              <li class="list-inline-item">
                Category
              </li>
              <li class="list-inline-item">
               Sub Category 
              </li>
          </ul>
          <p class="text-16">
            It is a long established fact that a reader will be distracted by will be distracted by the readable conte It is a long established fact that a reader will be distracted by will be distracted by the readable conte. It is a long established fact that a reader will be distracted by will be distracted by the readable conte...More
          </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\hispanic\resources\views/profile.blade.php ENDPATH**/ ?>