
<?php $__env->startSection('content'); ?>
    <section style="background-image: url('svg/ads.png');height:100px;">

    </section>
    <section class="my-3">
        <div class="container-fluid">
            <div class="row m-0 p-0">

<div class="col-md-2">
    <img src="<?php echo e(asset('svg/profile.jpg')); ?>" width="100" height="100" class="rounded-circle" alt="">
    <h3 class="text-18 font-weight-bold pt-3">
        Tauseef Ahmed
    </h3>
    <h4 class="text-16">
        tauseefahmed782@gmail.com
    </h4>

    <ul class="list-group mt-2">
      <a href="<?php echo e(route('add.new.post')); ?>" class="text-color">
          <li class="list-group-item  ">Add New Post</li>
      </a>
      <li class="list-group-item ">My Posts</li>
      <li class="list-group-item">Draft</li>
      <li class="list-group-item">Change profile</li>
      <li class="list-group-item">My Ads</li>
      <li class="list-group-item">My Yellow</li>
      <li class="list-group-item">Subscription</li>
      <li class="list-group-item">Event Creation</li>
      <li class="list-group-item active">Activities</li>
      <li class="list-group-item">Notifications</li>
  </ul>
</div>

                <div class="col-md-8 ">
                    
                    <div class="row">
                        <div class="col-md-6 d-flex align-items-center">
                            <h3 class="text-22 font-weight-bold mb-4">
                                My Activities </h3>
                        </div>
                        <div class="col-md-6 text-right">
                            
                            <ul class="list-inline mb-0 pb-0">
                                <li class="list-inline-item font-weight-bold ">
                                    <form action="">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                              <input type="checkbox" class="form-check-input " name="" id="" value="checkedValue">
                                              Clear All                                      </label>
                                          </div>
                                    </form>

                                </li>
                               

                            </ul>
                        </div>
                    </div>
                   
                   <p class="text-14">
                    Viewed Post’s
                   </p>
                    
                    <div class="mt-3">
                        
                        <div class="card p-2 shadow-none custom_grey ">
                            <div class="row">
                                <div class="col-md-2 d-flex align-items-md-center">
                                    <img src="<?php echo e(asset('svg/post.png')); ?> " class="img img-fluid" alt="">
                                </div>
                                <div class="col-md-7">
                                    <p class="text-16 font-weight-bold pb-2 mb-0">
                                        Foxy’s Restaurants
                                    </p>
                                    <p class="pb-2 text-14 mb-0">
                                        It is a long established fact that a reader will be distracted by will be..More
                                    </p>
                                    
                                    <p class="text-12 grey-color">
                                        https://www.youtube.com/watch?v=zbIeCycHiOI
                                    </p>
                                    
                                    <ul class="list-inline m-0 p-0">
                                        <li class="list-inline-item">
                                            <a href="http://" class="btn shadow-none btn-sm btn-custom">Contact </a>
                                        </li>
                                            <li class="list-inline-item">
                                            <i class="far fa-thumbs-up "></i>  6205 
                                            <i class="far fa-thumbs-down pl-2"></i>   
                                            <i class="fa fa-share-alt px-2"></i>
                                            <i class="far fa-comment pl-1"></i>
                                        </li>
                                        <li class="list-inline-item pl-1">
                                            <p class="text-14">
                                              <i class="fas fa-star  grey-color  "></i> 4.5 (26)
                                            </p>
                                        </li>
                                       
                                    </ul>
                                </div>
                                <div class="col-md-3">
                                    
                                <p class="text-right pb-2 mb-0">
                                    <i class="fas   fa-trash text-14  text-danger"></i>
                                    </p>                                    

                                    
                                    <p class="pb-1">
                                        <img src="<?php echo e(asset('svg/map-pin.svg')); ?>" alt="" srcset=""> 500081, Hyderabad, 
                                        Hi tech city, white fields, Kondapur
                                    </p>
                                    <p class="text-left pb-2 mb-0">
                                        <i class="far fa-clock pr-1 "></i> OPEN NOW <span class="text-14">  
                                             </p>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2 text-center">
                    <img src="<?php echo e(asset('svg/ads2.jpg')); ?>" class="img img-fluid" style="height: 700px;" alt="">
                </div>
            </div>
        </div>
    </section>

    <!-- Button trigger modal -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\hispanic\resources\views/my_activities.blade.php ENDPATH**/ ?>