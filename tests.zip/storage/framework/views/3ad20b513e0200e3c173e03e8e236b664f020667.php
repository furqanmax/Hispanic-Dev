
<?php $__env->startSection('content'); ?>
    <section style="background-image: url('svg/ads.png');height:100px;">

    </section>
    <section class="my-3">
        <div class="container-fluid">
            <div class="row m-0 p-0">
                <div class="col-md-2">
                    <img src="<?php echo e(asset('svg/profile.jpg')); ?>" width="100" height="100" class="rounded-circle" alt="">
                    <h3 class="text-18 font-weight-bold pt-3">
                        Tauseef Ahmed
                    </h3>
                    <h4 class="text-16">
                        tauseefahmed782@gmail.com
                    </h4>

                    <ul class="list-group mt-2">
                        <a href="<?php echo e(route('add.new.post')); ?>" class="text-color">
                            <li class="list-group-item  ">Add New Post</li>
                        </a>
                        <li class="list-group-item ">My Posts</li>
                        <li class="list-group-item">Draft</li>
                        <li class="list-group-item">Change profile</li>
                        <li class="list-group-item ">My Ads</li>
                        <li class="list-group-item">My Yellow</li>
                        <li class="list-group-item active">My Jobs</li>
                        <li class="list-group-item">Subscription</li>
                        <li class="list-group-item ">Event Creation</li>
                        <li class="list-group-item">Activities</li>
                        <li class="list-group-item">Notifications</li>
                    </ul>
                </div>
                <div class="col-md-8">
                    
                    <h3 class="text-22 font-weight-bold pb-2">
                        Tell us what are you Selling
                    </h3>
                    <p class="mb-0 pb-0">
                        Select category and  Sub category
                    </p>
                    
                    
                    <div class="">
                       <form action="" class="grey-color text-14">
                       <div class="row">
                           <div class="col-md-7">
                            <div class="form-group mt-4">
                                <select class="form-control custom-select text-14 grey-color" name="" id="">
                                    <option>Category like this Books & magazine</option>
                                    <option></option>
                                </select>
                            </div>
                            <div class="form-group ">
                                <select class="form-control custom-select text-14 grey-color" name="" id="">
                                    <option>Sub category like this acessories</option>
                                    <option></option>
                                </select>
                            </div>
                            
                           </div>
                       </div>
                       <button type="submit" class="btn btn-custom shadow-none btn-sm  px-5">Next</button>
                       </form>
                    </div>
                </div>
                <div class="col-md-2 text-center">
                    <img src="<?php echo e(asset('svg/ads2.jpg')); ?>" class="img img-fluid" style="height: 700px;" alt="">
                </div>
            </div>
        </div>
    </section>

    <!-- Button trigger modal -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\hispanic\resources\views/buy_sell/sell_type.blade.php ENDPATH**/ ?>